package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class ClientDemo {

    private static SessionFactory factory;

    public static void main(String[] args) {
        factory = new Configuration().configure().buildSessionFactory();
        ClientDemo demo = new ClientDemo();

        // Insert operation
        Vehicle vehicle1 = new Vehicle();
        vehicle1.setName("Toyota");
        vehicle1.setModel("Corolla");
        vehicle1.setEngine("1.8L");
        vehicle1.setWheels(4);
        vehicle1.setSeats(5);

        demo.insertVehicle(vehicle1);

        // View operation
        demo.viewVehicles();

        factory.close();
    }

    public void insertVehicle(Vehicle vehicle) {
        Transaction transaction = null;
        try (Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.save(vehicle);
            transaction.commit();
            System.out.println("Vehicle inserted: " + vehicle);
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void viewVehicles() {
        try (Session session = factory.openSession()) {
            List<Vehicle> vehicles = session.createQuery("from Vehicle", Vehicle.class).list();
            System.out.println("Vehicles in the database:");
            for (Vehicle vehicle : vehicles) {
                System.out.println(vehicle);
            }
        }
    }
}
